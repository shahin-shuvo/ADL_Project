#include<bits/stdc++.h>
using namespace std;

int target,n;
int coin[1005],uses[1005],used[1005];
int dp[1005][1005];
int coin_maker(int i,int amount)
{
    if(i>=n)
    {
        if(amount==target) return 1;
        else return 0;
    }
    if(dp[i][amount] != -1) return dp[i][amount];
    int x=0,y=0;
    if(coin[i]+amount<=target)
    {
        used[i]++;
        if(used[i]<uses[i])
        x=coin_maker(i,amount+coin[i]);
    }
    y = coin_maker(i+1,amount);

    return dp[i][amount] = (x+y)%100000007;
}
main()
{

    freopen("input","r",stdin);
    int t,cas=0;
    //scanf("%d",&t);
    //while(t--)
    //{
    scanf("%d %d",&n,&target);
    for(int i=0;i<n;i++)
    {
        scanf("%d",&coin[i]);
    }
    for(int i=0;i<n;i++)
    {
        scanf("%d",&uses[i]);
    }
    memset(dp,-1,sizeof(dp));
    memset(used,0,sizeof(used));
    printf("Case %d: %d\n",++cas,coin_maker(0,0)%100000007);
   // }
}



